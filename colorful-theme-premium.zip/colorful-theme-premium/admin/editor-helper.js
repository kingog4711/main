// ボタン スタイル
/*
wp.blocks.registerBlockStyle('core/button', {
	name: 'small-button',
	label: 'COLORFUL デザイン1(通常サイズ)',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/button', {
	name: 'large-button',
	label: 'COLORFUL デザイン1(大サイズ)',
	isDefault: false,
});
*/
wp.blocks.registerBlockStyle('core/button', {
	name: 'skewlr',
	label: 'COLORFUL 動くアニメーション',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/button', {
	name: 'dokkun',
	label: 'COLORFUL 動くアニメーション2',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/button', {
	name: 'yureruj',
	label: 'COLORFUL 揺れるアニメーション',
	isDefault: false,
});
// 画像 スタイル
wp.blocks.registerBlockStyle('core/image', {
	name: 'shadow',
	label: 'COLORFUL 影',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/image', {
	name: 'shadow-border',
	label: 'COLORFUL 枠＋影',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/image', {
	name: 'shadow-under',
	label: 'COLORFUL 下に影をつける',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/image', {
	name: 'beveled',
	label: 'COLORFUL へこみ枠',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/image', {
	name: 'dash',
	label: 'COLORFUL ダッシュ線の枠',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/image', {
	name: 'underline',
	label: 'COLORFUL 下線',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/image', {
	name: 'frame-border',
	label: 'COLORFUL 枠線',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/image', {
	name: 'rounded-border',
	label: 'COLORFUL 枠線 角丸',
	isDefault: false,
});

// カラム スタイル
wp.blocks.registerBlockStyle('core/column', {
	name: 'white-shadow',
	label: 'COLORFUL 白背景＋影',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/column', {
	name: 'padding',
	label: 'COLORFUL 左右余白',
	isDefault: false,
});

// 見出し スタイル
wp.blocks.registerBlockStyle('core/heading', {
	name: 'webfont1',
	label: '【フォント】Noto Sans JP',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/heading', {
	name: 'webfont2',
	label: '【フォント】Noto Serif JP',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/heading', {
	name: 'webfont3',
	label: '【フォント】M PLUS Rounded 1c',
	isDefault: false,
});

wp.blocks.registerBlockStyle('core/heading', {
	name: 'webfont4',
	label: '【フォント】Kosugi',
	isDefault: false,
});

wp.blocks.registerBlockStyle('core/heading', {
	name: 'webfont5',
	label: '【フォント】Kosugi Maru',
	isDefault: false,
});

wp.blocks.registerBlockStyle('core/heading', {
	name: 'webfont6',
	label: '【フォント】RocknRoll One',
	isDefault: false,
});

wp.blocks.registerBlockStyle('core/heading', {
	name: 'webfont7',
	label: '【フォント】Shippori Mincho',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/heading', {
	name: 'webfont8',
	label: '【フォント】Stick',
	isDefault: false,
});

// 段落 スタイル
wp.blocks.registerBlockStyle('core/paragraph', {
	name: 'webfont1',
	label: '【フォント】Noto Sans JP',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/paragraph', {
	name: 'webfont2',
	label: '【フォント】Noto Serif JP',
	isDefault: false,
});

// グループ スタイル
wp.blocks.registerBlockStyle('core/group', {
	name: 'shadow-A',
	label: 'COLORFUL 影(外側) - A',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/group', {
	name: 'shadow-C',
	label: 'COLORFUL 影(外側) - A(余白なし)',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/group', {
	name: 'shadow-B',
	label: 'COLORFUL 影(外側) - B',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/group', {
	name: 'shadow-inset-A',
	label: 'COLORFUL 影(内側) - A',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/group', {
	name: 'shadow-inset-B',
	label: 'COLORFUL 影(内側) - B',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/group', {
	name: 'shadow-D',
	label: 'COLORFUL影（外側）- C',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/group', {
	name: 'suptext',
	label: 'COLORFUL ＼テキスト／',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/group', {
	name: 'balloon',
	label: 'COLORFUL 吹き出し',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/group', {
	name: 'diagonal',
	label: 'COLORFUL 斜め型',
	isDefault: false,
});

// リスト スタイル
wp.blocks.registerBlockStyle('core/list', {
	name: 'oval1',
	label: 'COLORFUL 丸ブレット｜赤',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'oval2',
	label: 'COLORFUL 丸ブレット｜青',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'oval3',
	label: 'COLORFUL 丸ブレット｜緑',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'oval4',
	label: 'COLORFUL 丸ブレット｜黄緑',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'oval5',
	label: 'COLORFUL 丸ブレット｜灰色',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'oval6',
	label: 'COLORFUL 丸ブレット｜薄い灰色',
	isDefault: false,
});

wp.blocks.registerBlockStyle('core/list', {
	name: 'chk-A1',
	label: 'COLORFUL チェック｜赤',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'chk-A2',
	label: 'COLORFUL チェック｜青',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'chk-A3',
	label: 'COLORFUL チェック｜緑',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'chk-A4',
	label: 'COLORFUL チェック｜黄緑',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'chk-A5',
	label: 'COLORFUL チェック｜灰色',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'chk-A6',
	label: 'COLORFUL チェック｜薄い灰色',
	isDefault: false,
});

wp.blocks.registerBlockStyle('core/list', {
	name: 'chk-B1',
	label: 'COLORFUL 被せチェック｜赤',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'chk-B2',
	label: 'COLORFUL 被せチェック｜青',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'chk-B3',
	label: 'COLORFUL 被せチェック｜緑',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'chk-B4',
	label: 'COLORFUL 被せチェック｜黄緑',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'chk-B5',
	label: 'COLORFUL 被せチェック｜灰色',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'chk-B6',
	label: 'COLORFUL 被せチェック｜薄い灰色',
	isDefault: false,
});
wp.blocks.registerBlockStyle('core/list', {
	name: 'chk-round1',
	label: 'COLORFUL 囲み丸チェック｜黄',
	isDefault: false,
});
