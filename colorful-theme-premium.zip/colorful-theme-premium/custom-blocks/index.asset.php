<?php return array('dependencies' => array('lodash','wp-block-editor', 'wp-blocks', 'wp-components', 'wp-data', 'wp-element', 'wp-i18n'), 'version' => '033804cc1612a4b9cd19');
