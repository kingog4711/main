/**
 * Phosphor icons
 */
import * as phIcons from './src';
import phPickableList from './list';
import setIcon from '../set-icon';

setIcon('ph', 'PhPhosphorLogoFill', phIcons, phPickableList);
