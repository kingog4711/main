/**
 * Feather Icons
 */
import * as fiIcons from './src';
import fiPickableList from './list';
import setIcon from '../set-icon';

setIcon('fi', 'FiFeather', fiIcons, fiPickableList);
