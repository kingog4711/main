/**
 * Ionicons
 */
import * as ioIcons from './src';
import ioPickableList from './list';
import setIcon from '../set-icon';

setIcon('io', 'IoLogoIonic', ioIcons, ioPickableList);
