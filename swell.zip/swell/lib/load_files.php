<?php
namespace SWELL_Theme\Load_Files;

if ( ! defined( 'ABSPATH' ) ) exit;

require_once T_DIRE . '/lib/load/separate.php';
require_once T_DIRE . '/lib/load/check_code.php';
require_once T_DIRE . '/lib/load/jquery.php';
require_once T_DIRE . '/lib/load/front.php';
require_once T_DIRE . '/lib/load/admin.php';
require_once T_DIRE . '/lib/load/block_assets.php';
